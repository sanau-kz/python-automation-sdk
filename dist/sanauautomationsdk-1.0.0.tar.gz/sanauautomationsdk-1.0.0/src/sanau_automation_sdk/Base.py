class Base:

    def __init__(self, region, domain, access_key):
        self.region = region
        self.domain = domain
        self.access_key = access_key
